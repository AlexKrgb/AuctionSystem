package submission;

import it.unibz.auction.rmi.RMIAuctionServer;

/**
 * Entry point conforme ai requisiti di consegna.
 */
public final class Server {
    private Server() {}

    public static void main(String[] args) throws Exception {
        RMIAuctionServer.main(args);
    }
}


